'use strict';

const $btn1 = window.document.getElementById('btn1');
$btn1.addEventListener('click',function(evt){
    window.alert('hi~');
});