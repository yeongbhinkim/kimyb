'use strict';


    writeBtn?.addEventListener('click', e => {
      location.href = "/bbs/add";   // get,  /bbs/add
    });
