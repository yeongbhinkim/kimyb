package com.kh.app3.web;

import lombok.Data;

@Data
public class Code {
  private String code;            //코드
  private String decode;          //디코드
}
