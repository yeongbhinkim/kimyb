package com.kh.app3.web;

public interface SessionConst {
  String LOGIN_MEMBER = "loginMember";
}