package com.kh.app3.test;

public class Main {
//  psvm
  public static void main(String[] args) {
//    Person p1 = new Person("홍길동",30);
//    log.info(p1.getName());
//    p1.study();
//    p1.smile();
  }
}
